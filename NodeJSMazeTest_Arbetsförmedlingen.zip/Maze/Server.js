// input maze
var matrix = [
  ["f", "f", "f", "f"],

  ["t", "t", "f", "t"],

  ["f", "f", "f", "f"],

  ["f", "f", "f", "f"]
];

var visited = [[], [], [], []];

// Find shortest path from source (0, 0) to
// destination (3, 0)
Search(matrix, 0, 0, 3, 0, visited);





//Method for Verification
function ValidValues(matrix, visited, row, col) {
  var rowSize = 3;
  var columnSize = 3;
  return (
    row >= 0 &&
    row <= rowSize &&    //change made
    col >= 0 &&
    col < columnSize &&
    matrix[row][col] == "f" &&
    !visited[row][col]
  );
}





//Main method.
function Search(matrix, sourceX, sourceY, destinationX, destinationY, visited) {
  var queue = [];
  //put value on end of queue
  queueData = { sourceX: sourceX, sourceY: sourceY, distance: 0 };
  queue.push(queueData);
  //assign some max value
  var minimumdistance = 1000;
  while (queue != null) {
    //movements up down left right
    var row = [-1, 0, 0, 1];
    var col = [0, -1, 1, 0];
    var queueValue = queue.shift();
    sourceX = queueValue.sourceX;
    sourceY = queueValue.sourceY;
    dist = queueValue.distance;
    if (sourceX == destinationX && sourceY == destinationY) {
      minimumdistance = dist;
      break;
    }
    for (var index = 0; index < 4; index++) {
      // check if it is possible to go to position
      // (i + row[k], j + col[k]) from current position
      if (
        ValidValues(matrix, visited, sourceX + row[index], sourceY + col[index])
      ) {
        // mark next cell as visited and enqueue it
        visited[sourceX + row[index]][sourceY + col[index]] = true;
        queue.push({
          sourceX: sourceX + row[index],
          sourceY: sourceY + col[index],
          distance: dist + 1
        });
      }
    }
  }
  if (minimumdistance != 1000) {
    console.log(
      "The shortest path from source to destination " +
        "has length " +
        minimumdistance
    );
  } else {
    console.log("Destination can't be reached from source");
  }
}
